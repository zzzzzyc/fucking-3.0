"""
DG-LAB 插件系统
允许外部插件扩展设备功能
"""

from .plugin_loader import PluginLoader

__all__ = ['PluginLoader'] 